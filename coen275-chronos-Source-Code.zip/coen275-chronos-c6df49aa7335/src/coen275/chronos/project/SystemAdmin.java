package coen275.chronos.project;

/**
 * 
 */
public class SystemAdmin extends User {

	/**
	 * Default constructor
	 */
	public SystemAdmin() {
		super();
	}

}