package coen275.chronos.service.impl;

import coen275.chronos.service.LoggingService;

/**
 * 
 */
public class LoggingImpl implements LoggingService {

	/**
	 * Default constructor
	 */
	public LoggingImpl() {
	}

	/**
	 * 
	 */
	@Override
	public void writeToLog() {
		// TODO implement here
	}

	/**
	 * 
	 */
	@Override
	public void readFromLog() {
		// TODO implement here
	}

}