package coen275.chronos.project;

/**
 * 
 */
public enum Role {
	MANAGER,
	TEAM_MEMBER,
	ADMIN,
	OWNER
}