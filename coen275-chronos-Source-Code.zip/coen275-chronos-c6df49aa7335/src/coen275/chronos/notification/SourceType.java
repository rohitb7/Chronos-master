package coen275.chronos.notification;

/**
 * 
 */
public enum SourceType {
	TASK,
	PROJECT
}