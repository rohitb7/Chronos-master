package coen275.chronos.notification;

/**
 * 
 */
public enum ChangeType {
	CREATE,
	MODIFY,
	UPDATE,
	DELETE
}