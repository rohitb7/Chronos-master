package coen275.chronos.service;

/**
 * 
 */
public interface LoggingService {

	void readFromLog();

	void writeToLog();

}