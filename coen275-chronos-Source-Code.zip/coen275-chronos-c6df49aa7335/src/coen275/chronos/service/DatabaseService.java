/**
 * 
 */
package coen275.chronos.service;

/**
 * @author kaushik
 *
 */
public class DatabaseService {

	public void save(Object o) {
		
	}
	public <T> T getObject(T  type) {
		return type;
	}
}
